# A2UI设计工作流SOP（自留版） - 小红书
A2UI设计工作流SOP（自留版）我观察到现在工作中有个有趣的现象，UE找各种AI去生成UI效果图。看起来每个人都有点成果，但一看整体排期——你会发现需求交付还是要两周。
基于此，我分享以下现在我所在团队正在使用的设计工作流，成熟项目应用 AI 的实战方法和马上能上手的实操技巧。欢迎大家在评论区一起讨论，共同进步~
    #vibedesign#SOP#UI#UX#AI展开全文18分钟前

![图片1](images/image_01.jpg)

![图片2](images/image_02.jpg)

![图片3](images/image_03.jpg)

![图片4](images/image_04.jpg)

![图片5](images/image_05.jpg)

![图片6](images/image_06.jpg)

